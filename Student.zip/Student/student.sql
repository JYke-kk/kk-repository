/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50719
 Source Host           : localhost:3306
 Source Schema         : day23

 Target Server Type    : MySQL
 Target Server Version : 50719
 File Encoding         : 65001

 Date: 13/01/2023 19:54:27
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student`  (
  `sno` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `gender` varchar(2) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `cno` int(11) NULL DEFAULT NULL,
  `time` date NULL DEFAULT NULL,
  PRIMARY KEY (`sno`) USING BTREE,
  UNIQUE INDEX `student_sno_uindex`(`sno`) USING BTREE,
  INDEX `student_class_cno_fk`(`cno`) USING BTREE,
  CONSTRAINT `student_class_cno_fk` FOREIGN KEY (`cno`) REFERENCES `class` (`cno`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 1024 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES (1001, '张三', '男', 1, '2021-09-13');
INSERT INTO `student` VALUES (1002, '李四', '女', 2, '2019-06-11');
INSERT INTO `student` VALUES (1003, '王五', '男', 3, '2020-09-13');
INSERT INTO `student` VALUES (1004, '赵六', '女', 1, '2022-09-07');
INSERT INTO `student` VALUES (1005, '古琦', '男', 1, '2021-09-07');
INSERT INTO `student` VALUES (1006, '黄文文', '男', 2, '2023-09-13');
INSERT INTO `student` VALUES (1007, '高慧慧', '女', 3, '2023-01-13');
INSERT INTO `student` VALUES (1008, '李昊', '男', 2, '2019-06-11');
INSERT INTO `student` VALUES (1009, '陆涛', '男', 3, '2020-09-13');
INSERT INTO `student` VALUES (1010, '向南', '女', 1, '2022-09-07');
INSERT INTO `student` VALUES (1011, '秦宇', '男', 3, '2021-09-07');
INSERT INTO `student` VALUES (1012, '张文', '女', 3, '2023-09-13');
INSERT INTO `student` VALUES (1013, '姚琪', '男', 1, '2021-09-13');
INSERT INTO `student` VALUES (1014, '林静', '男', 2, '2019-06-11');
INSERT INTO `student` VALUES (1015, '马晓优', '男', 3, '2020-09-13');
INSERT INTO `student` VALUES (1016, '安琪', '女', 1, '2022-09-07');
INSERT INTO `student` VALUES (1017, '粥粥', '男', 3, '2021-09-07');
INSERT INTO `student` VALUES (1018, '林丽鸥', '女', 2, '2021-09-13');
INSERT INTO `student` VALUES (1019, '李玉', '男', 2, '2019-06-11');
INSERT INTO `student` VALUES (1020, '张鑫', '男', 3, '2020-09-13');
INSERT INTO `student` VALUES (1021, '张曦', '女', 1, '2022-09-07');
INSERT INTO `student` VALUES (1022, '雯雯', '女', 3, '2021-09-07');
INSERT INTO `student` VALUES (1023, '李勇', '男', 1, '2021-09-13');

SET FOREIGN_KEY_CHECKS = 1;

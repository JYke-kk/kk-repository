package com.lzh.dao.impl;

import com.lzh.dao.StudentDao;
import com.lzh.domain.Classes;
import com.lzh.domain.Student;
import com.lzh.utils.jdbcUtils;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.util.List;

public class StudentDaoImpl implements StudentDao {
    private static JdbcTemplate jdbcTemplate = new JdbcTemplate(jdbcUtils.getDataSource());

    @Override
    public Student findStudentBySno(Integer sno) {
        try {
            String sql = "select * from student where sno = ?";
            Student student = jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<Student>(Student.class), sno);
            return student;
        }catch (Exception e){
            System.out.println("没有这个学号的学生信息,键入回车继续");
        }
        return null;
    }

    @Override
    public Classes findClassByCno(Integer cno) {
        try {
            String sql = "select * from class where cno = ?";
            Classes classes = jdbcTemplate.queryForObject(sql, new BeanPropertyRowMapper<Classes>(Classes.class), cno);
            return classes;
        }catch (Exception e){
            System.out.println("输入的班级号不存在,键入回车继续");
        }
        return null;
    }

    @Override
    public Integer updateStudent(Student student) {
        try{
            String sql = "update student set name = ? ,gender = ?  where sno = ?";
            int i = jdbcTemplate.update(sql, student.getName(), student.getGender(), student.getSno());
            return i;
        }catch (Exception e){
            System.out.println("学生信息修改失败,键入回车继续");
        }
        return null;
    }

    @Override
    public Integer deleteStudent(Integer sno) {
        try{
            String sql = "delete from student where sno = ? ";
            int i = jdbcTemplate.update(sql, sno);
            return i;
        }catch (Exception e){
            System.out.println("删除失败,键入回车继续");
        }
        return null;
    }

    @Override
    public Integer UpdateClass(Student student) {
        try{
            String sql = "update student set cno = ? ,time = ? where sno = ?";
            int i = jdbcTemplate.update(sql, student.getCno(), student.getTime(), student.getSno());
            return i;
        }catch (Exception e){
            System.out.println("修改班级信息失败,键入回车继续");
        }
        return null;
    }

    @Override
    public List<Student> findStudentsByCno(Integer cno) {
        try{
            String sql = "select * from student where cno = ? order by time,name ";
            List<Student> studentList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Student>(Student.class), cno);
            return studentList;
        }catch (Exception e){
            System.out.println("没有这个班级的学生信息,键入回车继续");
        }
        return null;
    }

    @Override
    public List<Student> findAllStudent() {
        try {
            String sql = "select * from student order by cno,time";
            List<Student> studentList = jdbcTemplate.query(sql, new BeanPropertyRowMapper<Student>(Student.class));
            return studentList;
        }catch (Exception e){
            System.out.println("查询信息失败,请检查服务器,键入回车继续..");
        }
        return null;
    }

    @Override
    public Integer addStudent(Student student) {
        try {
            String sql = "insert into student(name,gender,cno,time) values (?,?,?,?)";
            int i = jdbcTemplate.update(sql, student.getName(), student.getGender(), student.getCno(), student.getTime());
            return i;
        }catch (Exception e){
            System.out.println("添加学生信息失败,键入回车继续...");
        }
        return null;
    }
}

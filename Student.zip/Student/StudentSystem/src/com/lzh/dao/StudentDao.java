package com.lzh.dao;

import com.lzh.domain.Classes;
import com.lzh.domain.Student;

import java.util.List;

public interface StudentDao {

    public Student findStudentBySno(Integer sno);

    public Classes findClassByCno(Integer Cno);

    public Integer updateStudent(Student student);

    public Integer deleteStudent(Integer sno);

    public Integer UpdateClass(Student student);

    public List<Student> findStudentsByCno(Integer cno);

    public List<Student> findAllStudent();

    public Integer addStudent(Student student);
}

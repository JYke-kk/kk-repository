package com.lzh.domain;

public class Classes {
    private int cno;


    public Classes() {
    }

    public Classes(int cno) {
        this.cno = cno;
    }

    /**
     * 获取
     * @return cno
     */
    public int getCno() {
        return cno;
    }

    /**
     * 设置
     * @param cno
     */
    public void setCno(int cno) {
        this.cno = cno;
    }

    public String toString() {
        return "Classes{cno = " + cno + "}";
    }
}

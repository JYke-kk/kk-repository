package com.lzh.domain;

public class Student {
    private int sno;
    private String name;
    private String gender;
    private int cno;
    private String time;


    public Student() {
    }

    public Student( String name, String gender, int cno, String time) {
        this.sno = sno;
        this.name = name;
        this.gender = gender;
        this.cno = cno;
        this.time = time;
    }

    /**
     * 获取
     * @return sno
     */
    public int getSno() {
        return sno;
    }

    /**
     * 设置
     * @param sno
     */
    public void setSno(int sno) {
        this.sno = sno;
    }

    /**
     * 获取
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * 设置
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取
     * @return gender
     */
    public String getGender() {
        return gender;
    }

    /**
     * 设置
     * @param gender
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * 获取
     * @return cno
     */
    public int getCno() {
        return cno;
    }

    /**
     * 设置
     * @param cno
     */
    public void setCno(int cno) {
        this.cno = cno;
    }

    /**
     * 获取
     * @return time
     */
    public String getTime() {
        return time;
    }

    /**
     * 设置
     * @param time
     */
    public void setTime(String time) {
        this.time = time;
    }

    public String toString() {
        return "学号 : " + sno + ", 姓名 : " + name + "  , 性别 : " + gender + ", 班级号 : " + cno + ", 入班时间 : " + time ;
    }
}

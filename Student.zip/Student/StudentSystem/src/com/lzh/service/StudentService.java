package com.lzh.service;

import com.lzh.domain.Classes;
import com.lzh.domain.Student;

import java.util.List;

public interface StudentService {
    //学生信息的查找
    public Student findStudentBySno(String sno);
    //班级信息的查找
    public Classes findClassByCno(Integer Cno);
    //修改
    public Integer updateStudent(Student student);
    //删除
    public Integer deleteStudent(String sno);

    public Integer UpdateClass(Student student);

    public List<Student> findStudentsByCno(Integer cno);

    public List<Student> findAllStudent();

    public Integer addStudent(Student student);

}

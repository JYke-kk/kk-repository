package com.lzh.service.impl;

import com.lzh.dao.StudentDao;
import com.lzh.dao.impl.StudentDaoImpl;
import com.lzh.domain.Classes;
import com.lzh.domain.Student;
import com.lzh.service.StudentService;

import java.util.List;

public class StudentServiceImpl implements StudentService {
    private static StudentDao dao = new StudentDaoImpl();
    @Override
    public Student findStudentBySno(String sno) {
        int snum = Integer.parseInt(sno);

        return dao.findStudentBySno(snum);
    }

    @Override
    public Classes findClassByCno(Integer cno) {
        return dao.findClassByCno(cno);
    }

    @Override
    public Integer updateStudent(Student student) {
        return dao.updateStudent(student);
    }

    @Override
    public Integer deleteStudent(String sno) {
        return dao.deleteStudent(Integer.parseInt(sno));
    }

    @Override
    public Integer UpdateClass(Student student) {
        return dao.UpdateClass(student);
    }

    @Override
    public List<Student> findStudentsByCno(Integer cno) {
        return dao.findStudentsByCno(cno);
    }

    @Override
    public List<Student> findAllStudent() {
        return dao.findAllStudent();
    }

    @Override
    public Integer addStudent(Student student) {
        return dao.addStudent(student);
    }
}

package com.lzh.main;

import com.lzh.domain.Classes;
import com.lzh.domain.Student;
import com.lzh.service.StudentService;
import com.lzh.service.impl.StudentServiceImpl;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

public class App {
    /**
     * 主菜单界面
     *
     * */
    private static Scanner sc = new Scanner(System.in);
    private static StudentService service = new StudentServiceImpl();

    public static void main(String[] args) {
        Menu();
    }



    /*菜单*/
    public static void Menu(){
        System.out.println("==========欢迎来到学生管理系统==========");
        loop:while (true){
            System.out.println("1.修改学生信息");
            System.out.println("2.删除学生信息");
            System.out.println("3.修改班级信息");
            System.out.println("4.添加学生信息");
            System.out.println("5.查询学生");
            System.out.println("6.查询各班级学生");
            System.out.println("7.查询所有学生");
            System.out.println("8.退出");
            System.out.println("请输入选择");
            String choose = sc.nextLine();
            switch (choose){
                case "1":
                    //修改学生
                    updateStudent();
                    break;
                case "2":
                    //删除学生
                    deleteStudent();
                    break;
                case "3":
                    //修改班级
                    updateClass();
                    break;
                case "4":
                    addStudent();
                    break ;
                case "5":
                    searchStudent();
                    break ;
                case "6":
                    searchStudentByCno();
                    break ;
                case "7":
                    searchAll();
                    break ;
                case "8":
                    //退出
                    System.out.println("感谢使用,Bye~");
                    break loop;
                default:
                    System.out.println("请输入正确选项,键入回车继续");
                    sc.nextLine();
                    break ;
            }
        }
    }

    /*修改学生*/
    public static void updateStudent(){
        System.out.println("请输入您要修改学生的学号");
        String sno = sc.nextLine();
        Student student = service.findStudentBySno(sno);
        if (student==null){
            sc.nextLine();
            return;
        }
        //查询到了
        System.out.println("请输入要修改的学生姓名");
        String name = sc.nextLine();
        System.out.println(name);
        System.out.println("请输入要修改的学生性别");
        String gender = sc.nextLine();

        student.setName(name);
        student.setGender(gender);


        //修改信息
        Integer integer = service.updateStudent(student);
        if (integer==1){
            System.out.println("学生信息修改成功,键入回车继续");
            sc.nextLine();
            return;
        }
    }

    /*删除学生*/
    public static void deleteStudent(){
        System.out.println("请输入要删除的学生学号");
        String sno = sc.nextLine();
        Student student = service.findStudentBySno(sno);
        if (student==null){
            sc.nextLine();
            return;
        }
        //存在则删除
        Integer integer = service.deleteStudent(sno);
        if (integer==1){
            System.out.println("删除成功,键入回车继续");
            sc.nextLine();
            return;
        }
    }

    /*修改班级信息*/
    public static void updateClass(){
        System.out.println("请输入要修改的学生学号");
        String sno = sc.nextLine();
        Student student = service.findStudentBySno(sno);
        if (student==null){
            sc.nextLine();
            return;
        }
        //学生存在
        System.out.println("请输入要修改的学生班级号");
        String classno = sc.nextLine();
        Classes classByCno = service.findClassByCno(Integer.parseInt(classno));
        if (classByCno==null){
            sc.nextLine();
            return;
        }

        long times = System.currentTimeMillis();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String time = simpleDateFormat.format(times);

        student.setCno(Integer.parseInt(classno));
        student.setTime(time);
        Integer integer = service.UpdateClass(student);
        if (integer==1){
            System.out.println("修改班级信息成功,键入回车继续");
            sc.nextLine();
            return;
        }
        sc.nextLine();
    }

    /*查找学生信息*/
    public static void searchStudent(){
        System.out.println("请输入学生学号");
        String sno = sc.nextLine();
        Student student = service.findStudentBySno(sno);
        System.out.println(student);
        System.out.println("键入回车继续");
        sc.nextLine();

    }

    /*通过班级查找学生信息*/
    public static void searchStudentByCno(){
        System.out.println("请输入班级号");
        String cno = sc.nextLine();
        try {
            Classes classes = service.findClassByCno(Integer.parseInt(cno));
            if (classes==null){
                sc.nextLine();
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("输入的班级号格式有误,键入回车继续");
            sc.nextLine();
        }

        List<Student> studentList = service.findStudentsByCno(Integer.parseInt(cno));
        if (studentList==null||studentList.size()==0){
            sc.nextLine();
            return;
        }
        for (Student student : studentList) {
            System.out.println(student);
        }
        System.out.println("键入回车继续");
        sc.nextLine();

    }

    /*查找所有学生信息*/
    public static void searchAll(){
        List<Student> studentList = service.findAllStudent();
        if (studentList!=null&&studentList.size()!=0){
            for (Student student : studentList) {
                System.out.println(student);
            }
            System.out.println("键入回车继续");
            sc.nextLine();
            return;
        }
        sc.nextLine();
    }

    /*添加学生*/
    public static void addStudent(){
        System.out.println("请输入要添加的学生姓名");
        String name = sc.nextLine();
        System.out.println("请输入学生性别");
        String gender = sc.nextLine();
        System.out.println("请输学生班级");
        String cno = sc.nextLine();
        try {
            Classes classes = service.findClassByCno(Integer.parseInt(cno));
            if (classes==null){
                sc.nextLine();
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("输入的班级号格式有误,键入回车继续");
            sc.nextLine();
        }
        long times = System.currentTimeMillis();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String time = simpleDateFormat.format(times);

        Student student = new Student(name, gender, Integer.parseInt(cno), time);
        Integer integer = service.addStudent(student);
        if (integer==null){
            sc.nextLine();
            return;
        }
        System.out.println("添加学生信息成功,键入回车继续");
        sc.nextLine();
    }
}
